public class User {

    private String name;
    private double balance;
    private Portfolio portfolio;

    public User(String name, double balance) {

        this.name = name;
        this.balance = balance;
        this.portfolio = new Portfolio();
    }

    public double getBalance() {
        return balance;
    }

    public Portfolio getPortfolio() {
        return portfolio;
    }

    public void buyStock(Stock stock, int quantity) {

        double cost = stock.getPrice() * quantity;

        if (balance >= cost) {

            balance -= cost;

            portfolio.buyStock(
                stock.getSymbol(),
                quantity
            );

            System.out.println(
                "Purchase Successful"
            );

        } else {

            System.out.println(
                "Insufficient Balance"
            );
        }
    }

    public void sellStock(Stock stock, int quantity) {

        double amount =
            stock.getPrice() * quantity;

        portfolio.sellStock(
            stock.getSymbol(),
            quantity
        );

        balance += amount;

        System.out.println(
            "Stock Sold Successfully"
        );
    }
}
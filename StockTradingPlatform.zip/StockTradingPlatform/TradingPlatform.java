import java.util.ArrayList;

public class TradingPlatform {

    private ArrayList<Stock> stocks;
    private ArrayList<Transaction> transactions;

    public TradingPlatform() {

        stocks = new ArrayList<>();
        transactions = new ArrayList<>();

        stocks.add(new Stock("AAPL", "Apple", 150));
        stocks.add(new Stock("TSLA", "Tesla", 250));
        stocks.add(new Stock("GOOG", "Google", 300));
    }

    public void displayMarketData() {

        System.out.println("===== MARKET DATA =====");

        for (Stock stock : stocks) {
            stock.displayStock();
        }
    }

    public Stock findStock(String symbol) {

        for (Stock stock : stocks) {

            if (stock.getSymbol().equalsIgnoreCase(symbol)) {
                return stock;
            }
        }

        return null;
    }

    public void addTransaction(Transaction t) {
        transactions.add(t);
    }

    public void showTransactions() {

        for (Transaction t : transactions) {
            t.displayTransaction();
        }
    }
}
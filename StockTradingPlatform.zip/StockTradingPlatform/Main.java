import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        TradingPlatform platform = new TradingPlatform();

        User user = new User("Teja", 10000);

        int choice;

        do {

            System.out.println("\n===== STOCK TRADING PLATFORM =====");
            System.out.println("1. View Market");
            System.out.println("2. Buy Stock");
            System.out.println("3. View Portfolio");
            System.out.println("4. Exit");

            System.out.print("Enter Choice: ");
            choice = sc.nextInt();

            switch(choice) {

                case 1:

                    platform.displayMarketData();
                    break;

                case 2:

                    System.out.print("Enter Symbol: ");
                    String symbol = sc.next();

                    System.out.print("Enter Quantity: ");
                    int qty = sc.nextInt();

                    Stock stock = platform.findStock(symbol);

                    if(stock != null) {

                        user.buyStock(stock, qty);

                        platform.addTransaction(
                                new Transaction(
                                        symbol,
                                        qty,
                                        stock.getPrice(),
                                        "BUY"
                                )
                        );

                    } else {

                        System.out.println("Stock Not Found");
                    }

                    break;

                case 3:

                    user.getPortfolio().displayPortfolio();
                    break;

                case 4:

                    System.out.println("Program Ended");
                    break;

                default:

                    System.out.println("Invalid Choice");
            }

        } while(choice != 4);

        sc.close();
    }
}